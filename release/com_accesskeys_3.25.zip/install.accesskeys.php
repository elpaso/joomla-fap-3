<?php
/**
* Alter menu table if needed
*/
// Impedisce l'accesso diretto al file
defined( '_JEXEC' ) or die( 'Restricted access' );


?>